pc.script.create('shieldAttractor', function (app) {
    // Creates a new ShieldAttractor instance
    var ShieldAttractor = function (entity) {
        this.entity = entity;
    };

    ShieldAttractor.prototype = {
        // Called once after all resources are loaded and before the first update
        initialize: function () {
            this.entity.collision.on('triggerenter', this.onTriggerEnter, this)
        },
        onTriggerEnter: function (entity) {
            console.log(entity)
        },


        // Called every frame, dt is time in seconds since last update
        update: function (dt) {
        }
    };

    return ShieldAttractor;
});